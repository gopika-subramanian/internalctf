<div align="center">
<h1>Chat-Bot</h1>
<code>Chatbot</code> is a computer program that simulates a natural human conversation. Users communicate with a chatbot via the chat interface, like how they would talk to a real person. Chatbots interpret and process user's words or phrases and give an instant pre-set answer. A chatbot for website is a chatbot that lives on your website, as opposed to a third party platform. The purpose of a chatbot on your website can vary.
  </div>
  <br>
  <div align="center">
  <!-- Version -->
    <img src="https://img.shields.io/badge/Version-2.0-blue.svg?longCache=true&style=flat-square"
      alt="2.0" />
    <!-- Last Updated -->
    <img src="https://img.shields.io/badge/Updated-July 2, 2020-orange.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" />
  <!-- Status -->
    <img src="https://img.shields.io/badge/Status-Stable-green.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" />
  </div>
  
### This repository inspired by Jayed.

![alt text](https://github.com/AhsanFarabi/Chat-Bot/blob/master/ScreenShot.png?raw=true)


  <div align="center">
  <sub>A Simple Project with ❤
 </div>  
 
